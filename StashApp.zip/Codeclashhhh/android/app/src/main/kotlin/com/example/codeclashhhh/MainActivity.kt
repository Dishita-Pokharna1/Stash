package com.example.codeclashhhh

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()

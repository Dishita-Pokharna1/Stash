enum Platform { linkedin, instagram, youtube, twitter }

class SavedPost {
  final int id;
  final Platform platform;
  final String title;
  final String summary;
  final List<String> tags;
  final DateTime savedAt;
  final bool hasDeadline;
  final DateTime? deadline;
  final bool aiDetected;
  final String? originalUrl;

  SavedPost({
    required this.id,
    required this.platform,
    required this.title,
    required this.summary,
    required this.tags,
    required this.savedAt,
    this.hasDeadline = false,
    this.deadline,
    this.aiDetected = false,
    this.originalUrl,
  });

  factory SavedPost.fromJson(Map<String, dynamic> json) {
    return SavedPost(
      id: json['id'],
      platform: Platform.values.firstWhere(
        (e) => e.name == json['platform'],
        orElse: () => Platform.linkedin,
      ),
      title: json['title'],
      summary: json['summary'],
      tags: List<String>.from(json['tags'] ?? []),
      savedAt: DateTime.parse(json['saved_at']),
      hasDeadline: json['has_deadline'] ?? false,
      deadline: json['deadline'] != null ? DateTime.parse(json['deadline']) : null,
      aiDetected: json['ai_detected'] ?? false,
      originalUrl: json['original_url'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'platform': platform.name,
      'title': title,
      'summary': summary,
      'tags': tags,
      'has_deadline': hasDeadline,
      'deadline': deadline?.toIso8601String(),
      'ai_detected': aiDetected,
      'original_url': originalUrl,
    };
  }
}

import 'package:flutter/material.dart';
import '../models/saved_post.dart';
import '../widgets/saved_post_card.dart';
import '../widgets/stats_card.dart';
import '../widgets/upcoming_deadline_card.dart';
import '../services/api_service.dart';

class SavedScreen extends StatefulWidget {
  const SavedScreen({super.key});

  @override
  State<SavedScreen> createState() => _SavedScreenState();
}

class _SavedScreenState extends State<SavedScreen> {
  final ApiService _apiService = ApiService();
  List<SavedPost> _posts = [];
  bool _isLoading = true;
  int _totalItems = 0;
  int _activeReminders = 0;
  int _completedReminders = 0;
  bool _hasError = false;

  @override
  void initState() {
    super.initState();
    _fetchData();
  }

  Future<void> _fetchData() async {
    setState(() {
      _isLoading = true;
      _hasError = false;
    });

    try {
      // Fetch saved posts
      final postsResponse = await _apiService.getSavedPosts();
      final posts = postsResponse.map((post) => SavedPost.fromJson(post)).toList();

      // Fetch analytics
      final analyticsResponse = await _apiService.getAnalytics();

      setState(() {
        _posts = posts;
        _totalItems = analyticsResponse['total_posts'] ?? 0;
        _activeReminders = analyticsResponse['active_reminders'] ?? 0;
        _completedReminders = analyticsResponse['completed_reminders'] ?? 0;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _hasError = true;
        _isLoading = false;
      });
      
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to load data: $e'),
            action: SnackBarAction(
              label: 'Retry',
              onPressed: _fetchData,
            ),
          ),
        );
      }
    }
  }

  Future<void> _addNewPost() async {
    // Show dialog to add new post
    showDialog(
      context: context,
      builder: (context) => const AddPostDialog(),
    ).then((result) {
      if (result == true) {
        _fetchData(); // Refresh data
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Stash',
          style: TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.bold,
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _fetchData,
          ),
          IconButton(
            icon: const Icon(Icons.notifications_outlined),
            onPressed: () {},
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _hasError && _posts.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Text('Failed to load data'),
                      ElevatedButton(
                        onPressed: _fetchData,
                        child: const Text('Retry'),
                      ),
                    ],
                  ),
                )
              : RefreshIndicator(
                  onRefresh: _fetchData,
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const UpcomingDeadlineCard(),
                        const SizedBox(height: 20),
                        Row(
                          children: [
                            Expanded(
                              child: StatsCard(
                                number: _totalItems.toString(),
                                label: 'Total Items',
                                color: Colors.blue,
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: StatsCard(
                                number: _activeReminders.toString(),
                                label: 'Active\nReminders',
                                color: Colors.red,
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: StatsCard(
                                number: _completedReminders.toString(),
                                label: 'Marked Done',
                                color: Colors.green,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 24),
                        const Text(
                          'Recently Added',
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 16),
                        if (_posts.isEmpty)
                          const Center(
                            child: Padding(
                              padding: EdgeInsets.all(32.0),
                              child: Text(
                                'No saved posts yet.\nTap the + button to add your first post!',
                                textAlign: TextAlign.center,
                                style: TextStyle(color: Colors.grey),
                              ),
                            ),
                          )
                        else
                          ..._posts.map((post) => Padding(
                                padding: const EdgeInsets.only(bottom: 12),
                                child: SavedPostCard(post: post),
                              )),
                      ],
                    ),
                  ),
                ),
      floatingActionButton: FloatingActionButton(
        onPressed: _addNewPost,
        backgroundColor: Colors.purple,
        child: const Icon(Icons.add),
      ),
    );
  }
}

class AddPostDialog extends StatefulWidget {
  const AddPostDialog({super.key});

  @override
  State<AddPostDialog> createState() => _AddPostDialogState();
}

class _AddPostDialogState extends State<AddPostDialog> {
  final _titleController = TextEditingController();
  final _summaryController = TextEditingController();
  final _urlController = TextEditingController();
  Platform _selectedPlatform = Platform.linkedin;
  final List<String> _tags = [];
  bool _hasDeadline = false;
  DateTime? _deadline;
  bool _isLoading = false;

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: const Color(0xFF2A2A2A),
      title: const Text('Add New Post'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            DropdownButtonFormField<Platform>(
              value: _selectedPlatform,
              decoration: const InputDecoration(labelText: 'Platform'),
              items: Platform.values.map((platform) {
                return DropdownMenuItem(
                  value: platform,
                  child: Text(platform.name.toUpperCase()),
                );
              }).toList(),
              onChanged: (value) => setState(() => _selectedPlatform = value!),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _titleController,
              decoration: const InputDecoration(
                labelText: 'Title',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _summaryController,
              decoration: const InputDecoration(
                labelText: 'Summary',
                border: OutlineInputBorder(),
              ),
              maxLines: 3,
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _urlController,
              decoration: const InputDecoration(
                labelText: 'URL (optional)',
                border: OutlineInputBorder(),
              ),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Cancel'),
        ),
        ElevatedButton(
          onPressed: _isLoading ? null : _savePost,
          child: _isLoading
              ? const SizedBox(
                  width: 16,
                  height: 16,
                  child: CircularProgressIndicator(strokeWidth: 2),
                )
              : const Text('Save'),
        ),
      ],
    );
  }

  Future<void> _savePost() async {
    if (_titleController.text.trim().isEmpty || _summaryController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please fill in title and summary')),
      );
      return;
    }

    setState(() => _isLoading = true);

    try {
      final post = SavedPost(
        id: 0, // Will be set by backend
        platform: _selectedPlatform,
        title: _titleController.text.trim(),
        summary: _summaryController.text.trim(),
        tags: ['Manual'], // Default tag for manually added posts
        savedAt: DateTime.now(),
        hasDeadline: _hasDeadline,
        deadline: _deadline,
        originalUrl: _urlController.text.trim().isEmpty ? null : _urlController.text.trim(),
      );

      await ApiService().createSavedPost(post);
      
      if (mounted) {
        Navigator.pop(context, true); // Return true to indicate success
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Post saved successfully!')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to save post: $e')),
        );
      }
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  @override
  void dispose() {
    _titleController.dispose();
    _summaryController.dispose();
    _urlController.dispose();
    super.dispose();
  }
}

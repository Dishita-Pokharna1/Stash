import 'package:flutter/material.dart';
import '../models/saved_post.dart';
import '../widgets/saved_post_card.dart';
import '../services/api_service.dart';

class SmartSortScreen extends StatefulWidget {
  const SmartSortScreen({super.key});

  @override
  State<SmartSortScreen> createState() => _SmartSortScreenState();
}

class _SmartSortScreenState extends State<SmartSortScreen> {
  final ApiService _apiService = ApiService();
  String selectedCategory = 'All';
  final List<String> categories = [
    'All',
    'Job',
    'Hackathon',
    'Scholarship',
    'Study',
    'Events',
    'Manual',
  ];
  
  List<SavedPost> _posts = [];
  bool _isLoading = true;
  bool _hasError = false;

  @override
  void initState() {
    super.initState();
    _fetchPosts();
  }

  Future<void> _fetchPosts() async {
    setState(() {
      _isLoading = true;
      _hasError = false;
    });

    try {
      final postsResponse = await _apiService.getSavedPosts(category: selectedCategory);
      final posts = postsResponse.map((post) => SavedPost.fromJson(post)).toList();

      setState(() {
        _posts = posts;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _hasError = true;
        _isLoading = false;
      });
      
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to load posts: $e')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'SmartSort',
          style: TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.bold,
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _fetchPosts,
          ),
        ],
      ),
      body: Column(
        children: [
          Container(
            height: 60,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: categories.length,
              itemBuilder: (context, index) {
                final category = categories[index];
                final isSelected = category == selectedCategory;
                return Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: FilterChip(
                    label: Text(category),
                    selected: isSelected,
                    onSelected: (selected) {
                      setState(() {
                        selectedCategory = category;
                      });
                      _fetchPosts();
                    },
                    backgroundColor: const Color(0xFF2A2A2A),
                    selectedColor: Colors.purple,
                    labelStyle: TextStyle(
                      color: isSelected ? Colors.white : Colors.grey,
                    ),
                  ),
                );
              },
            ),
          ),
          Expanded(
            child: _isLoading
                ? const Center(child: CircularProgressIndicator())
                : _hasError
                    ? Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const Text('Failed to load posts'),
                            ElevatedButton(
                              onPressed: _fetchPosts,
                              child: const Text('Retry'),
                            ),
                          ],
                        ),
                      )
                    : _posts.isEmpty
                        ? Center(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  Icons.inbox_outlined,
                                  size: 64,
                                  color: Colors.grey[600],
                                ),
                                const SizedBox(height: 16),
                                Text(
                                  selectedCategory == 'All'
                                      ? 'No saved posts yet'
                                      : 'No posts in "$selectedCategory" category',
                                  style: TextStyle(
                                    color: Colors.grey[600],
                                    fontSize: 16,
                                  ),
                                ),
                              ],
                            ),
                          )
                        : RefreshIndicator(
                            onRefresh: _fetchPosts,
                            child: ListView.builder(
                              padding: const EdgeInsets.all(16),
                              itemCount: _posts.length,
                              itemBuilder: (context, index) {
                                final post = _posts[index];
                                return Padding(
                                  padding: const EdgeInsets.only(bottom: 12),
                                  child: SavedPostCard(post: post),
                                );
                              },
                            ),
                          ),
          ),
        ],
      ),
    );
  }
}

import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/saved_post.dart';
import '../models/reminder.dart';
import '../models/chat_message.dart';

class ApiService {
  // Change this based on your setup:
  // For Android emulator: 'http://10.0.2.2:8000'
  // For iOS simulator: 'http://localhost:8000'
  // For physical device: 'http://YOUR_COMPUTER_IP:8000'
  static const String _baseUrl = 'http://localhost:8000';
  
  final Map<String, String> _headers = {
    'Content-Type': 'application/json',
  };

  // Saved Posts
  Future<List<Map<String, dynamic>>> getSavedPosts({String? category}) async {
    try {
      String url = '$_baseUrl/saved-posts/';
      if (category != null && category != 'All') {
        url += '?category=$category';
      }
      
      final response = await http.get(Uri.parse(url), headers: _headers);
      
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        return List<Map<String, dynamic>>.from(data['posts']);
      } else {
        throw Exception('Failed to load saved posts: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Network error: $e');
    }
  }

  Future<Map<String, dynamic>> createSavedPost(SavedPost post) async {
    try {
      final response = await http.post(
        Uri.parse('$_baseUrl/saved-posts/'),
        headers: _headers,
        body: json.encode(post.toJson()),
      );
      
      if (response.statusCode == 200) {
        return json.decode(response.body);
      } else {
        throw Exception('Failed to create post: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Network error: $e');
    }
  }

  Future<void> deleteSavedPost(int postId) async {
    try {
      final response = await http.delete(
        Uri.parse('$_baseUrl/saved-posts/$postId'),
        headers: _headers,
      );
      
      if (response.statusCode != 200) {
        throw Exception('Failed to delete post: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Network error: $e');
    }
  }

  // Reminders
  Future<List<Map<String, dynamic>>> getReminders() async {
    try {
      final response = await http.get(
        Uri.parse('$_baseUrl/reminders/'),
        headers: _headers,
      );
      
      if (response.statusCode == 200) {
        return List<Map<String, dynamic>>.from(json.decode(response.body));
      } else {
        throw Exception('Failed to load reminders: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Network error: $e');
    }
  }

  Future<Map<String, dynamic>> createReminder(Reminder reminder) async {
    try {
      final response = await http.post(
        Uri.parse('$_baseUrl/reminders/'),
        headers: _headers,
        body: json.encode(reminder.toJson()),
      );
      
      if (response.statusCode == 200) {
        return json.decode(response.body);
      } else {
        throw Exception('Failed to create reminder: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Network error: $e');
    }
  }

  Future<Map<String, dynamic>> updateReminder(int reminderId, Map<String, dynamic> updates) async {
    try {
      final response = await http.put(
        Uri.parse('$_baseUrl/reminders/$reminderId'),
        headers: _headers,
        body: json.encode(updates),
      );
      
      if (response.statusCode == 200) {
        return json.decode(response.body);
      } else {
        throw Exception('Failed to update reminder: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Network error: $e');
    }
  }

  Future<void> deleteReminder(int reminderId) async {
    try {
      final response = await http.delete(
        Uri.parse('$_baseUrl/reminders/$reminderId'),
        headers: _headers,
      );
      
      if (response.statusCode != 200) {
        throw Exception('Failed to delete reminder: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Network error: $e');
    }
  }

  // Chat
  Future<List<Map<String, dynamic>>> getChatMessages() async {
    try {
      final response = await http.get(
        Uri.parse('$_baseUrl/chat/messages/'),
        headers: _headers,
      );
      
      if (response.statusCode == 200) {
        return List<Map<String, dynamic>>.from(json.decode(response.body));
      } else {
        throw Exception('Failed to load chat messages: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Network error: $e');
    }
  }

  Future<Map<String, dynamic>> sendChatMessage(String message) async {
    try {
      final response = await http.post(
        Uri.parse('$_baseUrl/chat/send/'),
        headers: _headers,
        body: json.encode({'message': message}),
      );
      
      if (response.statusCode == 200) {
        return json.decode(response.body);
      } else {
        throw Exception('Failed to send message: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Network error: $e');
    }
  }

  // Analytics
  Future<Map<String, dynamic>> getAnalytics() async {
    try {
      final response = await http.get(
        Uri.parse('$_baseUrl/analytics/'),
        headers: _headers,
      );
      
      if (response.statusCode == 200) {
        return json.decode(response.body);
      } else {
        throw Exception('Failed to load analytics: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Network error: $e');
    }
  }
}

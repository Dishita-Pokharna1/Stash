import uvicorn
from database import Base, engine

if __name__ == "__main__":
    # Create tables
    Base.metadata.create_all(bind=engine)
    
    # Run server
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        ssl_keyfile=None,
        ssl_certfile=None
    )
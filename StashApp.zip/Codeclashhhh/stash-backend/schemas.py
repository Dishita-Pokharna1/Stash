from pydantic import BaseModel, EmailStr, Field
from typing import List, Optional
from datetime import datetime
from enum import Enum
from models import PlatformEnum, ContentTypeEnum

class UserBase(BaseModel):
    email: EmailStr
    name: str

class UserCreate(UserBase):
    password: str = Field(..., min_length=6)

class User(UserBase):
    id: int
    created_at: datetime
    is_active: bool

    class Config:
        from_attributes = True

class Token(BaseModel):
    access_token: str
    token_type: str

class TokenData(BaseModel):
    email: str | None = None

class SavedPostBase(BaseModel):
    title: str
    description: Optional[str] = None
    platform: PlatformEnum
    tags: List[str] = []
    detected_type: ContentTypeEnum = ContentTypeEnum.OTHER
    original_url: Optional[str] = None

class SavedPostCreate(SavedPostBase):
    pass

class SavedPost(SavedPostBase):
    id: int
    user_id: int
    saved_at: datetime

    class Config:
        from_attributes = True

class ReminderBase(BaseModel):
    title: str
    due_date: datetime
    notes: Optional[str] = None
    completed: bool = False

class ReminderCreate(ReminderBase):
    pass

class ReminderUpdate(BaseModel):
    title: Optional[str] = None
    due_date: Optional[datetime] = None
    notes: Optional[str] = None
    completed: Optional[bool] = None

class Reminder(ReminderBase):
    id: int
    user_id: int
    created_at: datetime

    class Config:
        from_attributes = True

class ChatMessageBase(BaseModel):
    message: str
    is_user: bool = True

class ChatMessageCreate(ChatMessageBase):
    pass

class ChatMessage(ChatMessageBase):
    id: int
    user_id: int
    timestamp: datetime

    class Config:
        from_attributes = True

class AnalyticsResponse(BaseModel):
    posts_by_type: dict
    posts_by_platform: dict
    upcoming_reminders: int
    completed_reminders: int
    total_posts: int